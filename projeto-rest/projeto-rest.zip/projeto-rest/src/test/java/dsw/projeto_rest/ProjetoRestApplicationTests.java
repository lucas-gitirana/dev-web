package dsw.projeto_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
