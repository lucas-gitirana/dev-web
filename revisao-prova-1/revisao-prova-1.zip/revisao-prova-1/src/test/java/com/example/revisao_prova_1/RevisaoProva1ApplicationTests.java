package com.example.revisao_prova_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RevisaoProva1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
