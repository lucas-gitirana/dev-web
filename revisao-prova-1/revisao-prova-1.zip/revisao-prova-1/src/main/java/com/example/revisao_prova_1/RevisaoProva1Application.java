package com.example.revisao_prova_1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevisaoProva1Application {

	public static void main(String[] args) {
		SpringApplication.run(RevisaoProva1Application.class, args);
	}

}
